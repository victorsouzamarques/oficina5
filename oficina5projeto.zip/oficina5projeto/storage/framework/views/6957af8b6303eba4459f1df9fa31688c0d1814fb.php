<?php $__env->startSection('content'); ?>
<section id="criar-form">
<h1>Adicionar novo contato</h1>
<hr>
<form action="/contatos" id="formulario-criar" class="form-horizontal col-md-4 text-md-center" method="post" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>

<div class="form-group col-md-12">
<input type="hidden" class="form-control" id="contatosNome" name="usuario" value="<?php echo e(\Auth::user()->id); ?>">
</div>
<div class="form-group col-md-12">
<label for="image">Foto</label>
<input type="file" class="form-control" id="contatosImage"  name="image">
</div>
<div class="form-group col-md-12">
<label for="nome">Nome</label>
<input type="text" class="form-control" id="contatosNome" name="nome">
</div>
<div class="form-group col-md-12">
<label for="email">Email</label>
<input type="email" class="form-control" id="contatosEmail" name="email">
</div>
<div class="form-group col-md-12">
<label for="telefone">Telefone</label>
<input type="text" class="form-control" id="contatosTelefone" name="telefone">
</div>
<div class="form-group col-md-12">
<label for="nascimento">Aniversário</label>
<input type="date" class="form-control" id="contatosNascimento" name="nascimento">
</div>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
<button type="submit" class="btn btn-primary">Adicionar</button>
</form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>