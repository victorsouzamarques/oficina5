<?php $__env->startSection('content'); ?>
<section id="editar-pagina">
<h1>Editar Contato</h1>
<hr>
<form action="<?php echo e(url('contatos', [$contato->id])); ?>" id="formulario-criar" class="form-horizontal col-md-4 text-md-center" method="POST" enctype="multipart/form-data">
<input type="hidden" name="_method" value="PUT">
<?php echo e(csrf_field()); ?>

<!-- <div class="form-group col-md-12">
<label for="title">Foto</label>
<input type="file" value="<?php echo e($contato->image); ?>" class="form-control" id="contatosImage"  name="image">
</div> -->
<div class="form-group col-md-12">
<label for="description">Nome</label>
<input type="text" value="<?php echo e($contato->nome); ?>" class="form-control" id="contatosNome" name="nome">
</div>
<div class="form-group col-md-12">
<label for="description">Email</label>
<input type="email" value="<?php echo e($contato->email); ?>" class="form-control" id="contatosEmail" name="email">
</div>
<div class="form-group col-md-12">
<label for="description">Telefone</label>
<input type="text" value="<?php echo e($contato->telefone); ?>" class="form-control" id="contatosTelefone" name="telefone">
</div>
<div class="form-group col-md-12">
<label for="description">Aniversário</label>
<input type="date" value="<?php echo e($contato->nascimento); ?>" class="form-control" id="contatosNascimento" name="nascimento">
</div>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
<button type="submit" class="btn btn-primary">Alterar</button>
</form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>