<?php $__env->startSection('content'); ?>
<div class="jumbotron text-center">
<div  id="conteudo-show">
	<div class="voltar-inicial">
		<a href="<?php echo e(url('contatos')); ?>"><i class="far fa-arrow-alt-circle-left"></i></a>
	</div>
	<p>
	<div class='col-xs-12'>		
		<div id="imagem-detalhes" class="blocos-infos-detalhes">
            <a class="thumbnail fancybox" rel="ligthbox" href="/images/<?php echo e($contato->image); ?>">
            	<img class="img-responsive" alt="" src="/images/<?php echo e($contato->image); ?>" />
                <div class='text-center'>
                </div> <!-- text-center / end -->
            </a>
        </div>
        <div id="nome-detalhes" class="blocos-infos-detalhes">
			<p><i class="far fa-user"></i> <?php echo e($contato->nome); ?></p>
		</div>
        <div id="email-detalhes" class="blocos-infos-detalhes">
			<p><i class="far fa-envelope"></i> <?php echo e($contato->email); ?></p>
		</div>
		<div id="telefone-detalhes" class="blocos-infos-detalhes">
			<p><i class="fas fa-phone"></i> <?php echo e($contato->telefone); ?></p>
		</div>
		<div id="nascimento-detalhes" class="blocos-infos-detalhes">
			<p><i class="far fa-calendar-alt"></i> 	<?php echo e($contato->nascimento); ?></p>
		</div>
		<div id="botaoeditar">
		<div class="acoesdetalhes">
			<a href="<?php echo e(URL::to('contatos/' . $contato->id . '/edit')); ?>">
				<button type="button" class="btn btn-warning">Editar</button>
			</a>
		</div>
		<div class="acoesdetalhes">
			<form action="<?php echo e(url('contatos', [$contato->id])); ?>" method="POST">
			     <input type="hidden" name="_method" value="DELETE">
			   <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			   <input type="submit" class="btn btn-danger" value="Delete"/>
			</form>
		</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>