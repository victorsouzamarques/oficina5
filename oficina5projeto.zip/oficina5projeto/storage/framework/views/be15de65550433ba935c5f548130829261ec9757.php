<?php $__env->startSection('content'); ?>
<div id="conteudo-contatos">
	<div id="usuario-logado">
		<h1>Meus Contatos</h1>
	</div>
	<div id="criar-novo-contato">
		<a href="<?php echo e(url('contatos/create')); ?>"><i class="fas fa-plus-circle"></i></a>
	</div>
<?php $__currentLoopData = $contatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="contatos-agenda">
	<div class="imagem-contatos">
        <a class="thumbnail fancybox" rel="ligthbox" href="/contatos/<?php echo e($contato->id); ?>">
            <img class="img-responsive" alt="" src="/images/<?php echo e($contato->image); ?>" />
            <div class='text-center'>
                <small class='text-muted'><?php echo e($contato->nome); ?></small>
            </div> <!-- text-center / end -->
        </a>
    </div>
	<div class="acoes-contatos">
	<div class="editar-contatos botoes-contatos">
		<a href="<?php echo e(URL::to('contatos/' . $contato->id . '/edit')); ?>">
		<button type="button" class="btn btn-warning">Editar</button>
		</a>
	</div>
	<div class="excluir-contatos botoes-contatos">
	<form action="<?php echo e(url('contatos', [$contato->id])); ?>" method="POST">
	    <input type="hidden" name="_method" value="DELETE">
	   <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	   <input type="submit" class="btn btn-danger" value="Deletar"/>
	</form>
	</div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>